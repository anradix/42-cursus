/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cub3d.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fberger <fberger@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/02 02:24:46 by fberger           #+#    #+#             */
/*   Updated: 2019/12/17 04:16:54 by fberger          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CUB3D_H
# define CUB3D_H
# include "../libft/libft.h"
# include "../mlx/mlx.h"
# include <math.h>

/*
** struct
*/

typedef struct		s_game
{
	int				save;
	int				res_x;
	int				res_y;
	char			*path_no_t;
	char			*path_so_t;
	char			*path_we_t;
	char			*path_ea_t;
	char			*path_sp_t;
	int				col_floor_hex;
	int				col_ceiling_hex;
	char			*buffer;
	char			**map;
	int				map_y_len;
	int				*x_len_for_y;
	float			pos_x;
	float			pos_y;
	
	void			*mlx_init_ret;
	void			*mlx_new_win_ret;
	int				*mlx_new_img_ret;
	int				*img_buffer;
	int				*mlx_get_data_wall_no;
	int				*mlx_get_data_wall_so;
	int				*mlx_get_data_wall_we;
	int				*mlx_get_data_wall_ea;
	int				*mlx_get_data_sprite;
	void			*mlx_wall_no;
	void			*mlx_wall_so;
	void			*mlx_wall_we;
	void			*mlx_wall_ea;
	void			*mlx_sprite;
	int				bitpx;
	int				size_line;
	int				endian;
	int				bit_pix_wdw;
	int				size_line_wdw;
	int				endian_wdw;

	float			*distances;
	int				*sides;
	float			*hit_wall_x;
	int				*tex_x;
	float			*sprite_dist;
	float			*hit_sprite_x;

	float			camera_x;
	float			ray_pos_x;
	float			ray_pos_y;
	float			ray_dir_x;
	float			ray_dir_y;
	float			plane_x;
	float			plane_y;
	float			dir_x;
	float			dir_y;
	int				map_x;
	int				map_y;
	float			side_dist_x;
	float			side_dist_y;
	float			delta_dist_x;
	float			delta_dist_y;

	float			speed;
	int 			move_f;
	int 			move_b;
	int 			move_l;
	int 			move_r;
	int 			move_rl;
	int 			move_rr;
}					t_game;

typedef struct			s_sprite
{
	int 				order;
	float				pos_x;
	float				pos_y;
	float				distance;
	int 				hit_col;
	int 				counter;
	int 				map_x;
	int 				map_y;
	int 				side_in_px;
	int					y_start;
	int					y_end;
	struct s_sprite		*next;
}						t_sprite;
	
/*
** main.c
*/

int				get_textures(t_game *g);
int				update_win(t_game *g);
int				ft_mlx(t_game	*g);
int				main(int argc, char **argv);

/*
** parse.c
*/

int				parse_res(t_game *g, char *line);
int				build_buffer(t_game *game, char *line);
int				parse_path(t_game *g, char *line);
int				parse_line(t_game *g, char *line);
int				parse_args(int argc, char **argv, t_game **game);

/*
** parse_utils.c
*/

int				init_g(t_game *g, int argc, char **argv);
void			set_direction(t_game *g, char c);
int				parse_col(char *col, int *dest);
int				check_if_map_valid(t_game *g);
int				build_map(t_game *game);

/*
** utils.c
*/

void			print_game(t_game *g);
int				handle_error(t_game *g, char *error_msg);

/*
** raycast.c
*/

void			get_no_so_distances(t_game	*g, int col, int step_x, int side);
void			get_we_ea_distances(t_game	*g, int col, int step_y, int side);
void			set_step_xy_move_on_map(t_game	*g, int *step_x, int *step_y);
int				raycast(t_game	*g, int col, t_sprite *sprites);
int				loop_raycast(t_game	*g, t_sprite *sprites);

/*
** key.c
*/

int    			on_key_press(int key, t_game *g);
int     		on_key_release(int key, t_game *g);
int				update_img_buffer(t_game *g);

/*
** move.c
*/

void			update_pos_f(t_game *g);
void			update_pos_b(t_game *g);
void			update_pos_rr(t_game *g);
void			update_pos_rl(t_game *g);
void			update_pos_r(t_game *g);
void			update_pos_l(t_game *g);
void			update_pos(t_game *g);

/*
** draw.c
*/

void			draw_floor_and_ceiling(t_game *g, int x, int y);
void			draw_wall_col(t_game *g, int x, int y, int wall_pxl_high);

/*
** free.c
*/

void			free_map(t_game *g);
void			free_g(t_game *g);

/*
** bmp.c
*/

void			get_pixels(t_game *g, int res_y, int res_x, int fd);
unsigned char	*create_bitmap_file_header(int res_y, int res_x);
unsigned char	*create_bitmap_info_header(int res_y, int res_x);
int				create_bmp(t_game *g);

/*
** sprite.c
*/

t_sprite		*detect_sprites(t_game *g);
void			store_sprite_hit_col(t_game *g, t_sprite *sprites, int hit_col, int side, int step_x, int step_y);
void			display_sprites(t_game *g, t_sprite *sprites);

#endif
