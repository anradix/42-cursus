/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   key.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fberger <fberger@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/09 19:39:39 by fberger           #+#    #+#             */
/*   Updated: 2019/12/17 03:58:46 by fberger          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/cub3d.h"

/*
** https://github.com/VBrazhnik/FdF/wiki/How-to-handle-mouse-buttons-and-key-presses%3F
** 13 'w' -> avance
** 1  's' -> recule
** 126 up arrow -> avance
** 125 down arrow -> recule
** 12 'q' -> decale a gauche
** 14 'e' -> decale a droite
** 0  'a' -> rotate camera gauche
** 2  'd' -> rotate camera droite
** 123 left arrow -> rotate camera gauche
** 124 right arrow -> rotate camera droite
** 53 ESC
** 69 '+' -> accelerer
** 79 '-' -> ralentir
*/

int     on_key_press(int key, t_game *g)
{
    if (key == 13 || key == 126)
        g->move_f = 1;
	else if (key == 1 || key == 125)
        g->move_b = 1;
	else if (key == 12)
        g->move_l = 1;
	else if (key == 14)
        g->move_r = 1;
	else if (key == 0 || key == 123)
        g->move_rl = 1;
	else if (key == 2 || key == 124)
        g->move_rr = 1;
	else if (key == 69)
        g->speed = g->speed < .3 ? g->speed + .04 : g->speed;
    return (0);
}

int     on_key_release(int key, t_game *g)
{
    if (key == 13 || key == 126)
        g->move_f = 0;
	else if (key == 1 || key == 125)
        g->move_b = 0;
	else if (key == 12)
        g->move_l = 0;
	else if (key == 14)
        g->move_r = 0;
	else if (key == 0 || key == 123)
        g->move_rl = 0;
	else if (key == 2 || key == 124)
        g->move_rr = 0;
	else if (key == 53)
	{
		// mlx_destroy_window(g->mlx_init_ret, g->mlx_new_win_ret);
		free_g(g);
		exit(0);
	}
	else if (key == 78)
		g->speed = g->speed > .05 ? g->speed - .04 : g->speed;
    return (0);
}

int		update_img_buffer(t_game *g)
{
	int x;
	int	y;
	int wall_pxl_high;
	int wall_start;
	int wall_end;

	x = 0;
	while (x < g->res_x)
	{
		wall_pxl_high = abs((int)(g->res_y / g->distances[x]));
		wall_start = ft_max((int)(g->res_y / 2 - wall_pxl_high / 2), 0);
		wall_end = ft_min((int)(g->res_y / 2 + wall_pxl_high / 2), g->res_y);
		y = 0;
		while (y < (int)wall_start)
			draw_floor_and_ceiling(g, x, y++);
		while (y < (int)wall_end)
			draw_wall_col(g, x, y++, wall_pxl_high);
		x++;
	}
	return (1);
}
