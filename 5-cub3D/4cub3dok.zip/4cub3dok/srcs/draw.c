/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fberger <fberger@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/13 20:42:13 by fberger           #+#    #+#             */
/*   Updated: 2019/12/17 04:14:07 by fberger          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/cub3d.h"

void	draw_floor_and_ceiling(t_game *g, int x, int y)
{
	g->img_buffer[y * g->res_x + x] = g->col_ceiling_hex;
	g->img_buffer[ft_min(g->res_y - y, g->res_y)
	* g->res_x + x] = g->col_floor_hex;
}

void	draw_wall_col(t_game *g, int x, int y, int wall_pxl_high)
{
	int tex_y;

	if (g->sides[x] == 0 || g->sides[x] == 1)
	{
		tex_y = (((float)y * 2. - (float)g->res_y + (float)wall_pxl_high)
		* (float)(64 / 2) / (float)wall_pxl_high);
		if (g->sides[x] == 0)
			g->img_buffer[y * g->res_x + x] =
			g->mlx_get_data_wall_no[(int)tex_y * 64 + g->tex_x[x]];
		else
			g->img_buffer[y * g->res_x + x] =
			g->mlx_get_data_wall_so[(int)tex_y * 64 + g->tex_x[x]];
	}
	else
	{
		tex_y = (((float)y * 2. - (float)g->res_y + (float)wall_pxl_high)
		* (float)(64 / 2) / (float)wall_pxl_high);
		if (g->sides[x] == 2)
			g->img_buffer[y * g->res_x + x] =
			g->mlx_get_data_wall_we[(int)tex_y * 64 + g->tex_x[x]];
		else
			g->img_buffer[y * g->res_x + x] =
			g->mlx_get_data_wall_ea[(int)tex_y * 64 + g->tex_x[x]];
	}
}
