/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fberger <fberger@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/09 19:30:49 by fberger           #+#    #+#             */
/*   Updated: 2019/12/15 00:24:28 by fberger          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/cub3d.h"

void		print_game(t_game *g)
{
	int		y;
	int		x;

	printf("game->res_x = %d\n", g->res_x);
	printf("g->res_y = %d\n", g->res_y);
	printf("g->path_no_t = %s\n", g->path_no_t);
	printf("g->path_so_t = %s\n", g->path_so_t);
	printf("g->path_we_t = %s\n", g->path_we_t);
	printf("g->path_ea_t = %s\n", g->path_ea_t);
	printf("g->path_sp_t = %s\n", g->path_sp_t);
	printf("g->map_y_len = %d\n", g->map_y_len);
	y = -1;
	while (++y < g->map_y_len)
	{
		printf("map[%2d] = ", y);
		x = -1;
		while (++x < g->x_len_for_y[y])
			printf("%c ", g->map[y][x]);
		printf("\n");
	}
	printf("g->pos_x = %f\n", g->pos_x);
	printf("g->pos_y = %f\n\n", g->pos_y);
	printf("g->save = %d\n", g->save);
}

int			handle_error(t_game *g, char *error_msg)
{
	ft_putstr_fd("Error\n", 2);
	ft_putstr_fd(error_msg, 2);
	if (g)
		free_g(g);
	return (0);
}