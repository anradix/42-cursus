/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fberger <fberger@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/14 23:55:09 by fberger           #+#    #+#             */
/*   Updated: 2019/12/15 00:28:21 by fberger          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/cub3d.h"

void	free_map(t_game *g)
{
	int y;

	y = -1;
	while (++y < g->map_y_len)
		ft_strdel(&g->map[y]);
	free(g->map);
}

void	free_g(t_game *g)
{
	ft_strdel(&g->path_no_t);
	ft_strdel(&g->path_so_t);
	ft_strdel(&g->path_we_t);
	ft_strdel(&g->path_ea_t);
	ft_strdel(&g->path_sp_t);
	ft_strdel(&g->buffer);
	free_map(g);
	ft_memdel((void *)&g->mlx_init_ret);
	ft_memdel((void *)&g->mlx_new_win_ret);
	ft_memdel((void *)&g->mlx_new_img_ret);
	ft_memdel((void *)&g->img_buffer);
	ft_memdel((void *)&g->mlx_get_data_wall_no);
	ft_memdel((void *)&g->mlx_get_data_wall_so);
	ft_memdel((void *)&g->mlx_get_data_wall_we);
	ft_memdel((void *)&g->mlx_get_data_wall_ea);
	ft_memdel((void *)&g->mlx_get_data_sprite);
	ft_memdel(&g->mlx_wall_no);
	ft_memdel(&g->mlx_wall_so);
	ft_memdel(&g->mlx_wall_we);
	ft_memdel(&g->mlx_wall_ea);
	ft_memdel(&g->mlx_sprite);
	ft_memdel((void *)&g->distances);
	ft_memdel((void *)&g->sides);
	ft_memdel((void *)&g->hit_wall_x);
	ft_memdel((void *)&g->tex_x);
}