/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sprite.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fberger <fberger@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/15 18:52:32 by fberger           #+#    #+#             */
/*   Updated: 2019/12/17 04:20:50 by fberger          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/cub3d.h"

/*
** self exp
*/

void			print_sprites(t_sprite *sprites)
{
	t_sprite *s;
	int i;

	s = sprites;
	i = 0;
	while (s)
	{
		printf("s %d *************************\n", ++i);
		printf("s->order = %d\n", s->order);
		printf("s->pos_x = %4.2f\n", s->pos_x);
		printf("s->pos_y = %4.2f\n", s->pos_y);
		printf("s->distance = %4.2f\n", s->distance);
		printf("s->hit_col = %d\n", s->hit_col);
		printf("s->counter = %d\n", s->counter);
		printf("s->map_x = %d\n", s->map_x);
		printf("s->map_y = %d\n", s->map_y);
		printf("s->side_in_px = %d\n", s->side_in_px);
		printf("s->y_start = %d\n", s->y_start);
		printf("s->y_end = %d\n", s->y_end);
		s = s->next;
	}
}

/*
** count_sprites
*/

int			count_sprites(t_game *g)
{
	int x;
	int y;
	int nb_sprite;

	y = -1;
	nb_sprite = 0;
	while (++y < g->map_y_len)
	{
		x = -1;
		while (++x < g->x_len_for_y[y])
		{
			if (g->map[y][x] == '2')
				nb_sprite += 1;
		}
	}
	return (nb_sprite);
}

/*
** create sorted linked list
*/

t_sprite	*sort_and_add_sprite(t_game *g, t_sprite *sprites, int x, int y)
{
	t_sprite *new_sprite;
	t_sprite *sprite;
	t_sprite *previous;

	if (!(new_sprite = (t_sprite *)malloc(sizeof(t_sprite))))
		return (NULL);
	new_sprite->pos_x = x;
	new_sprite->pos_y = y;
	new_sprite->distance = ((x + .5) - g->pos_x) * ((x + .5) - g->pos_x) + ((y + .5) - g->pos_y) * ((y + .5) - g->pos_y);
	new_sprite->next = NULL;
	new_sprite->hit_col = 0;
	new_sprite->order = 0;
	new_sprite->counter = 0;
	new_sprite->map_x = 0;
	new_sprite->map_y = 0;
	new_sprite->side_in_px = 0;
	if (!sprites)
		return (new_sprite);
	else
	{
		sprite = sprites;
		previous = NULL;
		while (sprite)
		{
			if (new_sprite->distance > sprite->distance)
			{
				if (previous)
					previous->next = new_sprite;
				new_sprite->next = sprite;
				if (!previous)
					sprites = new_sprite;
				return (sprites);
			}
			previous = sprite;
			sprite = sprite->next;
		}
		previous->next = new_sprite;
	}
	return (sprites);
}

/*
** parse_sprites
*/

t_sprite		*parse_sprites(t_game *g)
{
	int x;
	int y;
	t_sprite *sprites;

	y = -1;
	sprites = NULL;
	while (++y < g->map_y_len)
	{
		x = -1;
		while (++x < g->x_len_for_y[y])
		{
			if (g->map[y][x] == '2')
			{
				if (!(sprites = sort_and_add_sprite(g, sprites, x, y)))
					return (NULL);
			}
		}
	}
	// print_sprites(sprites);
	return (sprites);
}

t_sprite 	*detect_sprites(t_game *g)
{
	int nb_sprite;
	t_sprite *sprites;

	nb_sprite = 0;
	if (!(nb_sprite = count_sprites(g)))
		/* return (NULL) */;
	sprites = NULL;
	if (!(sprites = parse_sprites(g)))
		return (NULL);
	return (sprites);
}

/*
** store hit col on res_x
*/

int		get_last_order(t_sprite *sprites)
{
	t_sprite *s;
	int order;

	s = sprites;
	order = 0;
	while (s)
	{
		if (s->order > order)
			order = s->order;
		s = s->next;
	}
	return (order + 1);
}

/*
** store hit col on res_x
*/

void		store_sprite_hit_col(t_game *g, t_sprite *sprites, int hit_col, int side, int step_x, int step_y)
{
	t_sprite *s;
	int i;

	s = sprites;
	i = 0;
	while (s)
	{
		s->counter += 1;
		if (s->order == 0 && g->map_x == (int)s->pos_x && g->map_y == (int)s->pos_y)
		{
			s->hit_col = hit_col;
			s->order = get_last_order(sprites);
			s->map_x = g->map_x;
			s->map_y = g->map_y;
			if (side == 0)
				s->side_in_px = abs((int)(g->res_y / fabs((g->map_x - g->ray_pos_x + (1 - step_x) / 2) / g->ray_dir_x)));
			else
				s->side_in_px = abs((int)(g->res_y / fabs((g->map_y - g->ray_pos_y + (1 - step_y) / 2) / g->ray_dir_y)));
			s->y_start = ft_max((int)(g->res_y / 2 - s->side_in_px / 2), 0);
			s->y_end = ft_min((int)(g->res_y / 2 + s->side_in_px / 2), g->res_y);
			// printf("\n1 | g->map_x = %d g->map_y = %d\n", g->map_x, g->map_y);
			// printf("2 | s->pos_x = %d s->pos_y = %d\n", (int)s->pos_x, (int)s->pos_y);
			// printf("match for s->order = %d\n", s->order);
			return ;
		}
		s = s->next;
	}
}

/*
** real stuff happens here
*/

void		display_sprites(t_game *g, t_sprite *sprites)
{
	t_sprite *s;
	int 	x;
	int 	y;

	print_sprites(sprites);
	s = sprites;
	while (s)
	{
		x = -1;
		while (++x < s->side_in_px)
		{
			y = s->y_start;
			while (++y < s->y_end)
			{
				g->img_buffer[y * g->res_x + (s->hit_col + x)] = 0x000000;
			}
		}
		s = s->next;
	}
}