/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fberger <fberger@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/01 23:14:10 by fberger           #+#    #+#             */
/*   Updated: 2019/12/17 04:21:02 by fberger          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/cub3d.h"

/*
** mlx_wall_x + mlx_get_data_addr_ret_x : get textures
*/

int		get_textures(t_game *g)
{
    int		res_x = g->res_x;
	int		res_y = g->res_y;

   	if (!(g->mlx_wall_no = mlx_xpm_file_to_image(g->mlx_init_ret, g->path_no_t,
	&res_x, &res_y)))
		return (0);
	else
		g->mlx_get_data_wall_no = (int*)mlx_get_data_addr(g->mlx_wall_no,
		&g->bitpx, &g->size_line, &g->endian);
	if (!(g->mlx_wall_so = mlx_xpm_file_to_image(g->mlx_init_ret, g->path_so_t,
	&res_x, &res_y)))
		return (0);
	else
		g->mlx_get_data_wall_so = (int*)mlx_get_data_addr(g->mlx_wall_so,
		&g->bitpx, &g->size_line, &g->endian);
	if (!(g->mlx_wall_we = mlx_xpm_file_to_image(g->mlx_init_ret, g->path_we_t,
	&res_x, &res_y)))
		return (0);
	else
		g->mlx_get_data_wall_we = (int*)mlx_get_data_addr(g->mlx_wall_we,
		&g->bitpx, &g->size_line, &g->endian);
	if (!(g->mlx_wall_ea = mlx_xpm_file_to_image(g->mlx_init_ret, g->path_ea_t,
	&res_x, &res_y)))
		return (0);
	else
		g->mlx_get_data_wall_ea = (int*)mlx_get_data_addr(g->mlx_wall_ea,
		&g->bitpx, &g->size_line, &g->endian);
	if (!(g->mlx_sprite = mlx_xpm_file_to_image(g->mlx_init_ret, g->path_ea_t,
	&res_x, &res_y)))
		return (0);
	else
		g->mlx_get_data_sprite = (int*)mlx_get_data_addr(g->mlx_sprite,
		&g->bitpx, &g->size_line, &g->endian);
	return (1);
}

/*
** update_pos
** raycast for each x
** update_img_buffer
** update win with img
*/

int		update_win(t_game *g)
{
	t_sprite *sprites;

	update_pos(g);
	if (!(sprites = detect_sprites(g)))
		/* return (0) */;
	loop_raycast(g, sprites);
	update_img_buffer(g);
	display_sprites(g, sprites);
	mlx_put_image_to_window(g->mlx_init_ret, (void*)g->mlx_new_win_ret,
	(void*)g->mlx_new_img_ret, 0, 0);
	// exit(0);
	return (0);
}

/*
** update_pos
** raycast for each x
** update_img_buffer
** update win with img
** O_CREAT : créer le fichier s'il n'existe pas
*/

// int	create_screenshot(t_game *g)
// {
// 	int fd;
// 	t_sprite *sprites;

// 	update_pos(g);
// 	loop_raycast(g, sprites);
// 	// detect_sprites(g);
// 	update_img_buffer(g);
// 	// detect_sprites(g);
// 	fd = open("fi.bmp", O_CREAT);
// 	close(fd);
// 	create_bmp(g);
// 	return (1);
// }

/*
** mlx_init_ret : init
** mlx_new_win_ret : create window
** mlx_new_img_ret : create image
** img_buffer : pixels
** get_textures(g)
** mlx_hook : listen events like js
** mlx_loop_hook : run update_win in loop
** finish with mlx_loop
*/

int    ft_mlx(t_game	*g)
{
	if (!(g->mlx_init_ret = mlx_init())
	|| (!(g->mlx_new_win_ret = mlx_new_window(g->mlx_init_ret, g->res_x,
	g->res_y, "cub3d win")))
	|| (!(g->mlx_new_img_ret = mlx_new_image(g->mlx_init_ret, g->res_x,
	g->res_y)))
	|| (!(g->img_buffer = (int*)mlx_get_data_addr(g->mlx_new_img_ret,
	&g->bit_pix_wdw, &g->size_line_wdw, &g->endian_wdw))))
		return (handle_error(g, "failed to init mlx\n"));
	if (!(get_textures(g)))
		return (handle_error(g, "failed to load textures\n"));
	// if (g->save)
	// 	return (create_screenshot(g));
	mlx_hook(g->mlx_new_win_ret, 2, 0, on_key_press, g);
	mlx_hook(g->mlx_new_win_ret, 3, 0, on_key_release, g);
    mlx_loop_hook(g->mlx_init_ret, update_win, g);
	mlx_loop(g->mlx_init_ret);
    return (1);
}

/*
** 1. parsing
** 2. if parsing ok use mlx
*/

int		main(int argc, char **argv)
{
	t_game	*g;

	if (!(parse_args(argc, argv, &g)))
			return (-1);
	print_game(g);
	if (!(ft_mlx(g)))
		return (-1);
	return (0);
}

/*
** TODO
** checker que le fichier fini bien a .cub
** leaks
** virer tous les printf
** screenshot > juste bien comprendre les operateurs binaires
** sprite
** fsanitize
** mettre fonctions en static
*/